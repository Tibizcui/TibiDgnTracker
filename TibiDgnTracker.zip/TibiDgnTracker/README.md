# TibiDgnTracker v1.0

Addon WoW – Tracker des entrées de donjons, raids, gouffres et tourmentes pour toutes les extensions.

## Fonctionnalités
- 🗺️ Interface listant toutes les instances par extension (Vanilla → Midnight)
- 📍 Bouton TomTom /way pour poser un waypoint directement depuis l'interface
- 🔍 Filtres par type : Donjon / Raid / Gouffre / Torghast / Tourment
- 📋 Pour chaque instance : nom, zone, coordonnées, accès (Horde/Alliance), chemin le plus court
- 🗓️ Onglets par extension avec couleurs emblématiques (style TibiRepTracker)
- 🔘 Bouton minimap orbital draggable

## Commandes
- `/tdg` ou `/tibidgn` — Ouvrir/fermer la fenêtre
- `/tdg help` — Afficher l'aide
- `/tdg map on/off` — Activer/désactiver les pins sur la carte

## Dépendances
- **TomTom** (optionnel, pour les waypoints /way)

## Extensions couvertes
Vanilla, TBC, WotLK, Cataclysme, MoP, WoD, Legion, BfA, Shadowlands, Dragonflight, The War Within, Midnight

## Installation
Copier le dossier `TibiDgnTracker` dans `Interface/AddOns/`

## Auteur
Tibiscui – Kirin Tor
